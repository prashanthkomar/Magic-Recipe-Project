﻿using System;
using Prism.Mvvm;
using System.Configuration;
using System.Net;
using System.Runtime.Serialization.Json;
using System.IO;
using Newtonsoft.Json;
using Prism.Commands;

namespace MagicRecipe.ViewModels
{
    public class SearchRecipeViewModel : BindableBase
    {
        public SearchRecipeViewModel()
        {
            _SearchText = "omelet";
            //WebAPIURL = ConfigurationManager.AppSettings["WebAPIURL"].ToString();
        }
        private string _SearchText;

        private string WebAPIURL { get; set; } = "http://www.recipepuppy.com/api/?i=onions,garlic&q=omelet&p=3";

        public string SearchText
        {
            get { return _SearchText; }
            set
            {
                // _SearchText = value;
                SetProperty(ref _SearchText, value);
                GetRecipyDetails();
            }
        }

        private DelegateCommand _SearchCommand;
        public DelegateCommand SearchCommand
        {
            get
            {
                if (_SearchCommand == null)
                {
                    _SearchCommand = new RelayCommand(param => this.Authenticate(param), null);
                }
                return _SearchCommand;
            }
        }

        private void GetRecipyDetails()
        {
            if (string.IsNullOrEmpty(WebAPIURL))
            {
                HttpWebRequest httpWebRequest = CreateRequest(WebAPIURL);
                //HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (WebResponse response = httpWebRequest.GetResponse())
                {
                    using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                    {
                        u = (DtUser)JsonConvert.DeserializeObject(reader.ReadToEnd(), u.GetType());
                        return u;
                    }
                }


                //WebResponse recipiesResponse = MakeRequest(recipiesRequest);
                //ProcessResponse(recipiesResponse);

                //WebRequest request = WebRequest.Create(WebAPIURL);
                //WebResponse ws = request.GetResponse();
                //JsonSerializer jsonSerializer = new JsonSerializer(typeof(PanoramioData));
                //PanoramioData photos = (PanoramioData)jsonSerializer.Deserialze(ws.GetResponseStream());
            }
        }

        private HttpWebRequest CreateRequest(string url)
        {


            HttpWebRequest request = null;
            try
            {
                request = WebRequest.Create(url) as HttpWebRequest;
                request.Method = "GET";
                request.Timeout = 80000;
            }
            catch (WebException Ex)
            {
            }
            catch (Exception Ex)
            {
            }
            return request;
        }

        //Create the request URL
        //public static string CreateRequest(string queryString)
        //{
        //    //string UrlRequest = "http://dev.virtualearth.net/REST/v1/Locations/" +
        //    //                               queryString +
        //    //                               "?key=" + BingMapsKey;
        //    return (queryString);
        //}

        //public static WebResponse MakeRequest(string requestUrl)
        //{
        //    try
        //    {
        //        HttpWebRequest request = WebRequest.Create(requestUrl) as HttpWebRequest;
        //        using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
        //        {
        //            if (response.StatusCode != HttpStatusCode.OK)
        //                throw new Exception(String.Format(
        //                "Server error (HTTP {0}: {1}).",
        //                response.StatusCode,
        //                response.StatusDescription));
        //            DataContractJsonSerializer jsonSerializer = new DataContractJsonSerializer(typeof(WebResponse));
        //            object objResponse = jsonSerializer.ReadObject(response.GetResponseStream());
        //            WebResponse jsonResponse
        //            = objResponse as WebResponse;
        //            return jsonResponse;
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine(e.Message);
        //        return null;
        //    }

        //}

        //static public void ProcessResponse(WebResponse locationsResponse)
        //{

        //    //int locNum = locationsResponse.ResourceSets[0].Resources.Length;

        //    //Get formatted addresses: Option 1
        //    //Get all locations in the response and then extract the formatted address for each location
        //    Console.WriteLine("Show all formatted addresses");
        //    for (int i = 0; i < locNum; i++)
        //    {
        //        Location location = (Location)locationsResponse.ResourceSets[0].Resources[i];
        //        Console.WriteLine(location.Address.FormattedAddress);
        //    }
        //    Console.WriteLine();

        //    //Get the Geocode Points for each Location
        //    for (int i = 0; i < locNum; i++)
        //    {
        //        Location location = (Location)locationsResponse.ResourceSets[0].Resources[i];
        //        Console.WriteLine("Geocode Points for " + location.Address.FormattedAddress);
        //        int geocodePointNum = location.GeocodePoints.Length;
        //        for (int j = 0; j < geocodePointNum; j++)
        //        {
        //            Console.WriteLine("    Point: " + location.GeocodePoints[j].Coordinates[0].ToString() + "," +
        //                                         location.GeocodePoints[j].Coordinates[1].ToString());
        //            double test = location.GeocodePoints[j].Coordinates[1];
        //            Console.Write("    Usage: ");
        //            for (int k = 0; k < location.GeocodePoints[j].UsageTypes.Length; k++)
        //            {
        //                Console.Write(location.GeocodePoints[j].UsageTypes[k].ToString() + " ");
        //            }
        //            Console.WriteLine("\n\n");
        //        }
        //    }
        //    Console.WriteLine();


        //    //Get all locations that have a MatchCode=Good and Confidence=High
        //    Console.WriteLine("Locations that have a Confidence=High");
        //    for (int i = 0; i < locNum; i++)
        //    {
        //        Location location = (Location)locationsResponse.ResourceSets[0].Resources[i];
        //        if (location.Confidence == "High")
        //            Console.WriteLine(location.Address.FormattedAddress);
        //    }
        //    Console.WriteLine();

        //    Console.WriteLine("Press any key to exit");
        //    Console.ReadKey();
        //}
    }
}